import React from 'react';

const products = [
  { id: 'p1', name: 'MYBLEND — 1kg Personalized Sachet', price: 3499, desc: 'First order personalized 1kg supply' },
  { id: 'p2', name: 'MYBLEND — Monthly Subscription', price: 2799, desc: 'Monthly personalized 1kg supply (auto-ship)' },
  { id: 'p3', name: 'MYBLEND — Sample Pack (3 flavors)', price: 599, desc: 'Try 3 popular flavors' },
];

function formatPrice(p) {
  return `₹${p.toLocaleString('en-IN')}`;
}

export default function Shop({ addToCart, cart, removeFromCart, updateQty }) {
  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <h2 className="text-4xl font-bold mb-8 text-center">Shop MYBLEND</h2>

      <div className="grid md:grid-cols-3 gap-6 mb-12">
        {products.map(prod => (
          <div key={prod.id} className="p-6 bg-gradient-to-br from-purple-900/40 to-pink-900/40 rounded-lg border border-purple-400/30">
            <h3 className="text-xl font-bold mb-2">{prod.name}</h3>
            <p className="text-purple-200 mb-4">{prod.desc}</p>
            <p className="text-2xl font-bold text-purple-400 mb-4">{formatPrice(prod.price)}</p>
            <button onClick={() => addToCart(prod)} className="w-full px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg font-bold">Add to cart</button>
          </div>
        ))}
      </div>

      <div className="bg-slate-900/50 p-6 rounded-lg border border-purple-400/30">
        <h3 className="text-2xl font-bold mb-4">Your Cart</h3>
        {cart.length === 0 ? (
          <p className="text-purple-300">Your cart is empty.</p>
        ) : (
          <div className="space-y-4">
            {cart.map(item => (
              <div key={item.id} className="flex items-center justify-between bg-slate-800 p-3 rounded-md">
                <div>
                  <div className="font-bold">{item.name}</div>
                  <div className="text-sm text-purple-300">{item.qty} × ₹{item.price}</div>
                </div>
                <div className="flex items-center gap-2">
                  <input type="number" min="1" value={item.qty} onChange={(e) => updateQty(item.id, Math.max(1, Number(e.target.value)))} className="w-16 px-2 py-1 rounded-md bg-slate-800 text-white border border-purple-400/20" />
                  <button onClick={() => removeFromCart(item.id)} className="px-3 py-1 rounded-md bg-red-600/30">Remove</button>
                </div>
              </div>
            ))}

            <div className="text-right font-bold text-purple-400">
              Total: ₹{cart.reduce((s, i) => s + i.price * i.qty, 0).toLocaleString('en-IN')}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
